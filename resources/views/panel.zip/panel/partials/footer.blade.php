


<footer class="footer">
          <div class="container">
            <div class="row">
              <div class="col-md-12 footer-copyright justify-content-center text-center">
                <p class="mb-0">Copyright © 2024 by 3Rare Dynamics. All rights reserved.</p>
              </div>
              <div class="col-md-6">
                <!--<p class="pull-right mb-0">Hand-crafted & made with<i class="fa fa-heart"></i></p>-->
              </div>
            </div>
          </div>
        </footer>