<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reply Mail</title>
</head>
<body>
    <h1>Reply to User</h1>
    
    <p>{{ $msg }}</p>

   
    <p>Thank you for using our platform!</p>

    {{-- You can include additional content or styling here --}}
</body>
</html>