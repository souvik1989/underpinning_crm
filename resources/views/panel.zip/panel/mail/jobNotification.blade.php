<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Notification</title>
</head>
<body>
   <p>Hello,</p>
<p>Your Have One Job Notification.{{$job->id}}</p>
<p>Thank you!</p>
</body>
</html>