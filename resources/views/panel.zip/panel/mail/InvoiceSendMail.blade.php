<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice</title>
</head>
<body>
   <p>Hello,</p>
<p>Your Invoice is attached to this email. Please find the details in the attached PDF.</p>
<p>Thank you!</p>
</body>
</html>