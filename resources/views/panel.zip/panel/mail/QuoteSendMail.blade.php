<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Quote</title>
</head>
<body>
   <p>Hello,</p>
<p>Your Quote is attached to this email. Please find the details in the attached PDF.</p>
<p>Thank you!</p>
</body>
</html>